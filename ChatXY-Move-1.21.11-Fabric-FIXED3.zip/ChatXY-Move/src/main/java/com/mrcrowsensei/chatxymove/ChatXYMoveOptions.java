package com.mrcrowsensei.chatxymove;

import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;

public final class ChatXYMoveOptions {
    private ChatXYMoveOptions() {}

    public static SimpleOption<Integer> horizontal(GameOptions options) {
        return new SimpleOption<Integer>(
                "chatxy_move.option.x",
                SimpleOption.emptyTooltip(),
                (optionText, value) -> Text.literal("Chat Horizontal Position: " + value),
                new SimpleOption.ValidatingIntSliderCallbacks(-500, 500, true),
                ChatXYMoveConfig.getX(),
                ChatXYMoveConfig::setX
        );
    }

    public static SimpleOption<Integer> vertical(GameOptions options) {
        return new SimpleOption<Integer>(
                "chatxy_move.option.y",
                SimpleOption.emptyTooltip(),
                (optionText, value) -> Text.literal("Chat Vertical Position: " + value),
                new SimpleOption.ValidatingIntSliderCallbacks(-300, 300, true),
                ChatXYMoveConfig.getY(),
                ChatXYMoveConfig::setY
        );
    }
}
