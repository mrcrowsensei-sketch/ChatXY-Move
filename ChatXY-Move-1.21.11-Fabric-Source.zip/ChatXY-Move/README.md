# ChatXY-Move — 1.21.11 Fabric

This build fixes the `SimpleOption<Integer>` generic inference error from the previous ZIP.

The options use Minecraft 1.21.11's built-in `SimpleOption.ValidatingIntSliderCallbacks`.

Build:
1. Upload this project ZIP to the repository using the existing workflow.
2. Run `Actions -> Build ChatXY-Move`.
3. Download the `ChatXY-Move-JAR` artifact.
