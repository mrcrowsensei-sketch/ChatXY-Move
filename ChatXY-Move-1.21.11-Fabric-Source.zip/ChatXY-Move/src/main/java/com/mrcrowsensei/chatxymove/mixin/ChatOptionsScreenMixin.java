package com.mrcrowsensei.chatxymove.mixin;

import com.mrcrowsensei.chatxymove.ChatXYMoveOptions;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.gui.screen.option.ChatOptionsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Arrays;

@Mixin(ChatOptionsScreen.class)
public abstract class ChatOptionsScreenMixin {
    @Inject(
            method = "getOptions(Lnet/minecraft/client/option/GameOptions;)[Lnet/minecraft/client/option/SimpleOption;",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void chatxyMove$addOptions(
            GameOptions options,
            CallbackInfoReturnable<SimpleOption<?>[]> cir
    ) {
        SimpleOption<?>[] vanilla = cir.getReturnValue();

        SimpleOption<?>[] combined = Arrays.copyOf(vanilla, vanilla.length + 2);
        combined[vanilla.length] = ChatXYMoveOptions.horizontal(options);
        combined[vanilla.length + 1] = ChatXYMoveOptions.vertical(options);

        cir.setReturnValue(combined);
    }
}
