package com.mrcrowsensei.chatxymove;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ChatXYMoveConfig {
    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("chatxy-move.properties");

    private static int x = 0;
    private static int y = 0;

    private ChatXYMoveConfig() {}

    public static void load() {
        Properties properties = new Properties();

        if (Files.exists(FILE)) {
            try (InputStream in = Files.newInputStream(FILE)) {
                properties.load(in);
                x = clamp(parse(properties.getProperty("x"), 0), -500, 500);
                y = clamp(parse(properties.getProperty("y"), 0), -300, 300);
            } catch (IOException ignored) {
                x = 0;
                y = 0;
            }
        }
    }

    public static int getX() {
        return x;
    }

    public static int getY() {
        return y;
    }

    public static void setX(int value) {
        x = clamp(value, -500, 500);
        save();
    }

    public static void setY(int value) {
        y = clamp(value, -300, 300);
        save();
    }

    private static int parse(String value, int fallback) {
        if (value == null) return fallback;
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static void save() {
        Properties properties = new Properties();
        properties.setProperty("x", Integer.toString(x));
        properties.setProperty("y", Integer.toString(y));

        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                properties.store(out, "ChatXY-Move settings");
            }
        } catch (IOException ignored) {
            // The current values remain active for this session.
        }
    }
}
