# ChatXY-Move — Minecraft 1.21.11 Fabric

Fixed build project.

The previous error was caused by using a one-parameter lambda for
`SimpleOption.ValueTextGetter`. Minecraft 1.21.11 expects two parameters:
the option Text and the Integer value.

This version uses:
`(optionText, value) -> Text.literal(...)`

Build it with the existing GitHub Actions workflow.
