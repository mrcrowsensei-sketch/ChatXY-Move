# ChatXY-Move

Fabric client-side mod for Minecraft Java Edition **1.21.11**.

## What it does

Adds two sliders to Minecraft's **Options → Chat Settings**:

- **Chat Horizontal Position**: -500 to +500
  - negative = left
  - positive = right
- **Chat Vertical Position**: -300 to +300
  - negative = up
  - positive = down

The values are saved in `config/chatxy-move.properties`.

## Build with GitHub

1. Create a new GitHub repository.
2. Upload all files from this project ZIP, keeping the folder structure.
3. Commit to `main`.
4. Open the repository's **Actions** tab.
5. Open **Build ChatXY-Move**.
6. Wait for the build to finish.
7. Open the completed workflow run.
8. Under **Artifacts**, download **ChatXY-Move-jar**.
9. Put the generated `.jar` into your Fabric `mods` folder for Minecraft 1.21.11.

## Important

This is a source/build project ZIP, not a precompiled `.jar`. GitHub Actions performs the Gradle build.

The chat HUD is translated visually with Minecraft's 1.21.11 2D GUI matrix stack. The chat input box itself is not moved.
