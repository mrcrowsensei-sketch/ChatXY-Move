package com.mrcrowsensei.chatxymove;

import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;

import java.util.Optional;

public final class ChatXYMoveOptions {
    private ChatXYMoveOptions() {}

    public static SimpleOption<Integer> horizontal(GameOptions options) {
        return new SimpleOption<>(
                "chatxy_move.option.x",
                SimpleOption.emptyTooltip(),
                (text, value) -> Text.literal(text.getString() + ": " + value),
                new IntSliderCallbacks(-500, 500),
                ChatXYMoveConfig.getX(),
                ChatXYMoveConfig::setX
        );
    }

    public static SimpleOption<Integer> vertical(GameOptions options) {
        return new SimpleOption<>(
                "chatxy_move.option.y",
                SimpleOption.emptyTooltip(),
                (text, value) -> Text.literal(text.getString() + ": " + value),
                new IntSliderCallbacks(-300, 300),
                ChatXYMoveConfig.getY(),
                ChatXYMoveConfig::setY
        );
    }

    private static final class IntSliderCallbacks implements SimpleOption.SliderCallbacks<Integer> {
        private final int min;
        private final int max;

        private IntSliderCallbacks(int min, int max) {
            this.min = min;
            this.max = max;
        }

        @Override
        public com.mojang.serialization.Codec<Integer> codec() {
            return com.mojang.serialization.Codec.INT;
        }

        @Override
        public Optional<Integer> validate(Integer value) {
            if (value == null) {
                return Optional.empty();
            }
            return Optional.of(Math.max(min, Math.min(max, value)));
        }

        @Override
        public double toSliderProgress(Integer value) {
            return (value - min) / (double) (max - min);
        }

        @Override
        public Integer toValue(double progress) {
            return (int) Math.round(min + progress * (max - min));
        }
    }
}
