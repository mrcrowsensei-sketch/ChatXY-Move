package com.mrcrowsensei.chatxymove;

import net.fabricmc.api.ClientModInitializer;

public final class ChatXYMoveClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ChatXYMoveConfig.load();
    }
}
