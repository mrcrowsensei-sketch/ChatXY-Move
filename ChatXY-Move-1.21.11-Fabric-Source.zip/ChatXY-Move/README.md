# ChatXY-Move — Fixed Build

Fabric client-side Minecraft 1.21.11 mod project.

## Fix in this version

The previous build failed because Minecraft 1.21.11 already provides
`SimpleOption.ValidatingIntSliderCallbacks`, so the custom slider callback
was unnecessary and used the wrong API.

This version uses the 1.21.11 API directly.

## GitHub build

Upload the project files to your repository, then run the included
`.github/workflows/build.yml` workflow.

The resulting JAR is uploaded as the `ChatXY-Move-JAR` artifact.
