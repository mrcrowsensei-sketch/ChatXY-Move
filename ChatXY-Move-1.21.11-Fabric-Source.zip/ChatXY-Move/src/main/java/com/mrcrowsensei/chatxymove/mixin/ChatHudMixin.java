package com.mrcrowsensei.chatxymove.mixin;

import com.mrcrowsensei.chatxymove.ChatXYMoveConfig;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    @Inject(
            method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V",
            at = @At("HEAD")
    )
    private void chatxyMove$pushTransform(
            DrawContext context,
            TextRenderer textRenderer,
            int currentTick,
            int mouseX,
            int mouseY,
            boolean interactable,
            boolean bool,
            CallbackInfo ci
    ) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(
                ChatXYMoveConfig.getX(),
                ChatXYMoveConfig.getY()
        );
    }

    @Inject(
            method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V",
            at = @At("RETURN")
    )
    private void chatxyMove$popTransform(
            DrawContext context,
            TextRenderer textRenderer,
            int currentTick,
            int mouseX,
            int mouseY,
            boolean interactable,
            boolean bool,
            CallbackInfo ci
    ) {
        context.getMatrices().popMatrix();
    }
}
